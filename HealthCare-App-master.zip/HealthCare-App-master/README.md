# HealthCare-App
This Application Helps the patients who suffer from diabetes to maintain there sugar level. Support from version 4 to till dated. Please fork and work, don't push anything here. 

## Android Application - Diabetes Patients  
### Building it
build.gradle

Note: 
1. Target SDK 27
2. Will no longer support Android Studio <3.0.